

 
/**
 *
 * @author Hamad s3619196
 */
public class MiniNet {

    public static void main(String[] args) {
        new Driver();
    }
    
}
